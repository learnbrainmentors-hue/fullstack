// Seeded random numbers (Mulberry32 algorithm).
// Same seed -> same numbers on every computer, so any result can be re-checked.
// (Math.random() can't be seeded, so we can't use it here.)
export function createRandom(seed) {
  let state = seed >>> 0;
  return function next() {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296; // number between 0 and 1
  };
}

// "Bell curve" random number (Box-Muller). Market moves are mostly small, sometimes big.
export function bellCurve(random) {
  const u1 = random() || Number.MIN_VALUE; // avoid log(0)
  const u2 = random();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
