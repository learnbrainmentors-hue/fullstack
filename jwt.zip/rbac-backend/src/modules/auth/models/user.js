import mongoose, { Schema} from 'mongoose';
const userSchema = new Schema({
    name : {type:String, required:true},
    email :{type:String, required:true, unique: true, lowercase:true},
    password: {type:String, required:true},
    role : {type: mongoose.Schema.Types.ObjectId, ref :'roles', required:true}
});
export const UserModel = mongoose.model("users", userSchema);