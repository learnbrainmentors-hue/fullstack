import { emitToAll, EVENTS } from '../../shared/socket/index.js';

// Who is connected RIGHT NOW. Kept in memory: sockets can't be saved in a database.
// After a server restart it starts empty, and workers simply reconnect.
class WorkerRegistry {
  #workers = new Map(); // name -> { name, socket, busy, tasksDone, joinedAt }
  #banned = new Set();

  add(name, socket) {
    this.#workers.set(name, { name, socket, busy: false, tasksDone: 0, joinedAt: new Date() });
    this.broadcast();
  }

  remove(name) {
    this.#workers.delete(name);
    this.broadcast();
  }

  get(name) {
    return this.#workers.get(name);
  }

  has(name) {
    return this.#workers.has(name);
  }

  list() {
    return [...this.#workers.values()];
  }

  ban(name) {
    this.#banned.add(name);
  }

  isBanned(name) {
    return this.#banned.has(name);
  }

  // safe version for the browser: everything except the socket object
  toPublic() {
    return this.list().map(({ name, busy, tasksDone, joinedAt }) => ({ name, busy, tasksDone, joinedAt }));
  }

  // tell every open dashboard the new worker list
  broadcast() {
    emitToAll(EVENTS.WORKERS_UPDATE, this.toPublic());
  }
}

// One shared instance for the whole app (ES modules are cached, so this is a singleton)
export const workerRegistry = new WorkerRegistry();
