import { workerColor } from '../lib/workers.js';

// One square per task. Coloured squares show WHICH machine did each task.
// Grey squares are done tasks we have no colour for (e.g. after a page refresh).
export default function TaskGrid({ total, done, cells = {} }) {
  const coloured = Object.keys(cells).length;
  return (
    <div className="grid" role="img" aria-label={`${done} of ${total} tasks done`}>
      {Array.from({ length: total }, (_, i) => {
        const worker = cells[i];
        const isDone = worker || (coloured === 0 && i < done);
        return (
          <span
            key={i}
            className={`cell ${isDone ? 'done' : ''}`}
            style={worker ? { background: workerColor(worker) } : undefined}
            title={worker ? `Task ${i + 1}: ${worker}` : `Task ${i + 1}`}
          />
        );
      })}
    </div>
  );
}
