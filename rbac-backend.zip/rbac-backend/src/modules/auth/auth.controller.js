import { registerService } from "./auth.service.js";

export const login = (req, res)=>{
    const userInfo = req.body;
}
export const register = async (req, res)=>{
     const userInfo = req.body;
     let result = await registerService(userInfo);
     if(result){
        res.status(200).json({message:'User Register'});
     }
     else{
        res.status(500).json({message: 'Error During Register'});
     }
     
}