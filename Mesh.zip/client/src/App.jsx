import { useAuth } from './context/AuthContext.jsx';
import AuthPage from './pages/AuthPage.jsx';
import DashboardPage from './pages/DashboardPage.jsx';

// Two screens only: logged out -> AuthPage, logged in -> DashboardPage
export default function App() {
  const { user, loading } = useAuth();
  if (loading) return null;
  return user ? <DashboardPage /> : <AuthPage />;
}
