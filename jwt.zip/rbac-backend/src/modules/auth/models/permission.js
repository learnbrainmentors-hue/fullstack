import mongoose, { Schema } from "mongoose";
// _id
const permissionSchema = new Schema({
    name:{type:String, unique:true, required:true},
    description : {type:String, default:''}
});
export const PermissionModel = mongoose.model('permissions', permissionSchema);