import jwt from 'jsonwebtoken';
export const createAccessToken = (user)=>{
    console.log(' createAccessToken ', user);
    return jwt.sign({
        sub :user._id.toString(), role : user.role.name,
    },process.env.ACCESS_SECRET_KEY, {expiresIn:'1m'})
}

export const createRefreshToken = (user)=>{
    return jwt.sign({
        sub :user._id.toString(), role : user.role.name,
    },process.env.REFRESH_SECRET_KEY, {expiresIn:'7d'})
}

// secure the token
export const refreshTokenHttpCookieOptions = {
    httpOnly:true,
    secure:false, // true when on https,
   // sameSite : 'strict'
   path : '/api/v1',
   maxAge : 7 * 24 * 60 * 60 * 1000
}