import { z } from 'zod';
import { createRandom, bellCurve } from './random.js';

const SIMULATIONS_PER_TASK = 50_000;

// "If I invest X every month for Y years, what's my chance of losing money?"
// We imagine many possible futures (Monte Carlo) and count the bad ones.
export const sipRisk = {
  type: 'sip-risk',
  title: 'SIP Risk Simulator',
  description: 'Chance of loss and expected value of a monthly SIP (Monte Carlo).',

  schema: z.object({
    monthlyAmount: z.number().min(100).max(1_000_000),
    years: z.number().int().min(1).max(30),
    expectedReturn: z.number().min(-0.5).max(0.5).default(0.12), // 12% a year
    volatility: z.number().min(0.01).max(1).default(0.18), // how wild the market is
    simulations: z.number().int().min(10_000).max(5_000_000).default(1_000_000),
    seed: z.number().int().min(1).default(42),
  }),

  // 1. SPLIT: 1,000,000 simulations -> 20 tasks of 50,000, each with its own seed
  split(params) {
    const tasks = [];
    for (let done = 0, i = 0; done < params.simulations; done += SIMULATIONS_PER_TASK, i++) {
      const count = Math.min(SIMULATIONS_PER_TASK, params.simulations - done);
      tasks.push({ ...params, simulations: count, seed: params.seed + i });
    }
    return tasks;
  },

  // 2. RUN one task (on a worker). Same input -> same output, always.
  run({ monthlyAmount, years, expectedReturn, volatility, simulations, seed }) {
    const random = createRandom(seed);
    const months = years * 12;
    const invested = monthlyAmount * months;
    const drift = expectedReturn / 12 - (volatility * volatility) / 24; // average monthly growth
    const shock = volatility / Math.sqrt(12); // size of a monthly random move

    let sum = 0;
    let losses = 0;
    for (let s = 0; s < simulations; s++) {
      let value = 0;
      for (let m = 0; m < months; m++) {
        value = (value + monthlyAmount) * Math.exp(drift + shock * bellCurve(random));
      }
      sum += value;
      if (value < invested) losses++;
    }
    // send back small totals, not 50,000 numbers: totals can simply be added together
    return { simulations, sum, losses };
  },

  // 3. MERGE all task results into the final answer
  merge(results, params) {
    const simulations = results.reduce((a, r) => a + r.simulations, 0);
    const sum = results.reduce((a, r) => a + r.sum, 0);
    const losses = results.reduce((a, r) => a + r.losses, 0);
    return {
      invested: params.monthlyAmount * params.years * 12,
      averageValue: Math.round(sum / simulations),
      chanceOfLoss: Number(((losses / simulations) * 100).toFixed(2)), // percent
      simulations,
    };
  },
};
