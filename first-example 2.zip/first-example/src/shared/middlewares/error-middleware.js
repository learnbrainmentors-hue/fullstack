export const errorMiddleware = (err, req, res, next)=>{
    console.log('Error is ', err);
    res.status(500).json({error:'OOPS Something went Wrong...'});
}