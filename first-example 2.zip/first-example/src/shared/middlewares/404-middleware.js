export const errorMiddleware404 = (req, res)=>{
    res.status(404).json({message:'Resource Not Exist....'});
}