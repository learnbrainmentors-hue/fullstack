import jwt from 'jsonwebtoken';
export const authMiddleware = (req, res, next)=>{
    console.log('Headers are :::: ', req.headers.Authorization);
    const header = req.headers.authorization;
    if(!header){
        return res.status(401).json({message:'Access Token Missing'});
    }
    if(header && !header.startsWith("Bearer")){
        return res.status(401).json({message:'Access Token Missing....'});
    }
    console.log("--------------------------------------");
    const token = header.split(' ')[1] ; // Bearer <TokenNo>
    try{
    const payload = jwt.verify(token, process.env.ACCESS_SECRET_KEY);
    const user = payload.sub;
    console.log(user._id, user.role);
    // check permission , role 
    next();
    }
    catch(err){
         res.status(401).json({message:'Invalid or Expire Token'});
    }   
}