import { createAccessToken, createRefreshToken, refreshTokenHttpCookieOptions } from "../../shared/utils/token.js";
import { registerService } from "./auth.service.js";

export const login = (req, res)=>{
    const userInfo = req.body;
    // DB Check User Exist
    userInfo._id = '6b07d79a0060ba8c7ce56f9e';
    userInfo.role = {name:'guest'};
    const accessToken = sendTokens(userInfo, res);
    res.status(200).json({message:'Login SuccessFully', accessToken, userInfo});

}

const sendTokens = (user, res)=>{
   console.log('Send Token ', user);
   const accessToken = createAccessToken(user);
   const refreshToken = createRefreshToken(user);
   res.cookie('refreshToken', refreshToken, refreshTokenHttpCookieOptions);
   return accessToken;
}

export const refresh = (req, res)=>{
   // old refresh token verify 
    const accessToken = sendTokens(userInfo, res);
    res.status(200).json( {accessToken});
}

export const register = async (req, res)=>{
     const userInfo = req.body;
     let result = await registerService(userInfo);
     if(result){
        res.status(200).json({message:'User Register'});
     }
     else{
        res.status(500).json({message: 'Error During Register'});
     }
     
}