import mongoose from 'mongoose';
export const createConnection = async ()=>{
    return await mongoose.connect(process.env.DB_URL, 
        {maxPoolSize:20, serverSelectionTimeoutMS:5000})
}
export const disconnect = async ()=>{
   await mongoose.disconnect();
}