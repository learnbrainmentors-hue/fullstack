import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import mongoose from 'mongoose';
import { env } from './shared/config/env.js';
import { protect } from './shared/middlewares/auth.js';
import { requestLogger } from './shared/middlewares/requestLogger.js';
import { notFound, errorHandler } from './shared/middlewares/errorHandler.js';
import { listWorkloads } from './shared/workloads/index.js';
import authRoutes from './modules/auth/auth.routes.js';
import jobRoutes from './modules/jobs/job.routes.js';
import aiRoutes from './modules/ai/ai.routes.js';
import { workerRegistry } from './modules/workers/worker.registry.js';

export function createApp() {
  const app = express();

  app.use(helmet()); // security headers
  app.use(cors({ origin: env.CLIENT_URL })); // only our React app may call the API
  app.use(express.json({ limit: '100kb' })); // read JSON bodies, refuse huge ones
  app.use(requestLogger);

  // public routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', database: mongoose.connection.readyState === 1 ? 'up' : 'down' });
  });
  app.get('/api/workloads', (req, res) => res.json(listWorkloads()));
  app.use('/api/auth', authRoutes);

  // logged-in routes
  app.use('/api/jobs', protect, jobRoutes);
  app.use('/api/ai', protect, aiRoutes);
  app.get('/api/workers', protect, (req, res) => res.json(workerRegistry.toPublic()));

  app.use(notFound);
  app.use(errorHandler); // must be the last middleware
  return app;
}
