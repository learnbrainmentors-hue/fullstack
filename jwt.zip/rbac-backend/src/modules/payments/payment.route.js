import {Router} from 'express';
export const paymentRoutes = Router();

paymentRoutes.get('/payment', (req, res)=>{
    res.status(200).json({messsage:'Payment .....'});
})