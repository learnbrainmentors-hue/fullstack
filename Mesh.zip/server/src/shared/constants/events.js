// All Socket.IO event names in one place, so nobody can mistype one.
export const EVENTS = Object.freeze({
  TASK_RUN: 'task:run', // server -> worker: "run this task"
  TASK_DONE: 'task:done', // worker -> server: "here is the result"
  TASK_FAILED: 'task:failed', // worker -> server: "it crashed"
  JOB_UPDATE: 'job:update', // server -> browser: a job's progress changed
  TASK_UPDATE: 'task:update', // server -> browser: which worker finished which task
  WORKERS_UPDATE: 'workers:update', // server -> browser: list of online workers
});
