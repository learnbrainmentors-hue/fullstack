import express from 'express';
import { authRoutes } from './modules/auth/routes/auth-routes.js';
import {rateLimit} from 'express-rate-limit';
import { validateMiddleware } from './shared/middlewares/validate-middleware.js';
import { userSchema } from './modules/auth/schema/user-schema.js';
import { errorMiddleware } from './shared/middlewares/error-middleware.js';
import { errorMiddleware404 } from './shared/middlewares/404-middleware.js';
export const createApp = ()=>{
    const API_VERSION = "/api/v1";
    console.log('***** Express Type ', typeof express);
    const app = express();
     app.get('/health', (request, response)=>{
        //response.send("Hello Express ");
        response.status(200).json({status : 'OK', uptime : process.uptime()});
    })
  //  app.use(middlewareFunction);
    app.use(express.json()); // for every request (application level)
    const apiRateLimiter = rateLimit({limit:5, windowMs:60*1000})
    app.use('/api', apiRateLimiter); // path level
    //  app.use("Path",middlewareFunction);
    //app.use(`${API_VERSION}/user`, authRoutes); // Router Level 
    //const middleware = validateMiddleware(userSchema);
    //app.use(`${API_VERSION}/user`, middleware,authRoutes); // Route Level
    app.use(`${API_VERSION}/user`, validateMiddleware(userSchema) ,authRoutes); // Route Level
    app.get(`${API_VERSION}/api-boom`, (req, res)=>{
      throw new Error('Boom Boom Error');
    })
    // all rest of routes
    // at the end
   app.use(errorMiddleware); // Error Level
   
   app.use(errorMiddleware404);
    
    console.log('App is ', typeof app);
    return app;
}
