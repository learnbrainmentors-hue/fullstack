import winston from 'winston'; // logging library
const {combine, timestamp, json} = winston.format;
export const logger = winston.createLogger({
    level : "debug",
    format : combine(timestamp(), json()),
    transports:[
        new winston.transports.File({filename:"logs/error.log", level:'error'}),
        new winston.transports.File({filename:"logs/app.log"})
    ],
});