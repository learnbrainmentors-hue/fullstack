import {Router} from 'express';
import { me, register } from '../controllers/auth-controller.js';
export const authRoutes = Router();
// authRoutes.route('/user')
//            .get((request, response)=>{
//             // Logic
//                 response.send("Profile");
//            })
//            .post((request, response)=>{
//             // Logic
//                 response.send("Register")
//            });
authRoutes.get('/:username/:repo', (req, res)=>{
    res.send("User "+req.params.username +" Repo "+req.params.repo);
})  
authRoutes.get('/queryeg', (req, res)=>{
    const obj = req.query;
    console.log('Query ' , obj);
    res.send("Hello Query "+obj.brand+ " "+obj.price);
});
    authRoutes.get('/profile/:id', me);
    authRoutes.post('/register', register);

        //    authRoutes.route("/user")
        //    .get('/profile', me)
        //    .post("/register",register)