import http from 'http';
import { createApp } from './app.js';
const server = http.createServer(createApp());
server.listen(process.env.PORT || 1234, (err)=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running ', server.address().port);
    }
})