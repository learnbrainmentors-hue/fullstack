import { GoogleGenAI } from '@google/genai';
import { getWorkload, listWorkloads } from '../../shared/workloads/index.js';
import { env } from '../../shared/config/env.js';
import { ApiError } from '../../shared/utils/ApiError.js';
import { logger } from '../../shared/utils/logger.js';
import { parseWithRules } from './ai.rules.js';

// Create the Gemini client only if an API key is set
const gemini = env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: env.GEMINI_API_KEY }) : null;

// English sentence -> job PROPOSAL. It never creates or runs a job: the user clicks "Run".
export async function interpret(prompt) {
  if (gemini) {
    try {
      return toProposal(await askGemini(prompt), 'gemini');
    } catch (err) {
      logger.warn('Gemini failed, using rules instead', { reason: err.message });
    }
  }

  const guess = parseWithRules(prompt);
  if (!guess) throw ApiError.badRequest('Could not understand. Try: "SIP of 5000 for 3 years"');
  return toProposal(guess, 'rules');
}

// AI output is untrusted: it must pass the SAME validation as a human's input.
function toProposal({ type, params }, source) {
  const workload = getWorkload(type); // unknown type -> error
  return { type, params: workload.schema.parse(params), source }; // bad values -> error
}

async function askGemini(prompt) {
  // The prompt is built from our workload list, so new workloads are learned automatically.
  const instructions = `You convert a user's request into a compute job.
Available workloads (with a JSON Schema for their params):
${JSON.stringify(listWorkloads())}

Reply with JSON only, exactly like: {"type": "<workload type>", "params": { ... }}
Use only params from the schema. Turn words like "2 lakh" or "ten thousand" into numbers.
Write percentages as decimals (12% -> 0.12).

User request: """${prompt}"""`;

  const response = await gemini.models.generateContent({
    model: env.GEMINI_MODEL,
    contents: instructions,
    config: { responseMimeType: 'application/json', temperature: 0 }, // JSON only, no creativity
  });
  return JSON.parse(response.text);
}
