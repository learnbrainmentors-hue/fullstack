import mongoose from "mongoose";



const UserSchema = mongoose.Schema;
const userSchema = new UserSchema({
    email: {type:String, required:true, unique:true, trim:true, lowercase:true},
    password:{
        type:String, 
        required:true, 
        maxLength:[25,'Max Length Allowed is 25 Chars'],
         minLength:[8, 'Min Length Allowed is 8 Chars']},
    name:{
        type:String , 
        required:[true , 'Name is Missing'],
        maxLength:[25,'Max Length Allowed is 25 Chars']},
   role :{
    type:String,
    enum : ['user','admin'],
    default:'user'
   },
   isActive:{type:Boolean, default : true}          
},{timestamps:true} // createdAt and updatedAt
);
export const UserModel = mongoose.model('users', userSchema);