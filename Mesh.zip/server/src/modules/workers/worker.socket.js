import { env } from '../../shared/config/env.js';
import { EVENTS } from '../../shared/constants/events.js';
import { logger } from '../../shared/utils/logger.js';
import { workerRegistry } from './worker.registry.js';
import { assignWork, handleTaskDone, handleTaskFailed, handleWorkerLeft } from '../jobs/job.scheduler.js';

// Workers connect to their own namespace: ws://server/workers
export function registerWorkerSocket(io) {
  const workers = io.of('/workers');

  // Runs before a worker is let in. next(new Error()) rejects it.
  workers.use((socket, next) => {
    const { token, name } = socket.handshake.auth;
    if (token !== env.WORKER_TOKEN) return next(new Error('Invalid worker token'));
    if (!name) return next(new Error('Worker name is required'));
    if (workerRegistry.isBanned(name)) return next(new Error('This worker is banned'));
    if (workerRegistry.has(name)) return next(new Error(`A worker named "${name}" is already connected`));
    next();
  });

  workers.on('connection', (socket) => {
    const { name } = socket.handshake.auth;
    workerRegistry.add(name, socket);
    logger.info('Worker joined', { name });
    assignWork(); // a new worker is free: give it work

    // .catch so one bad message can never crash the server
    socket.on(EVENTS.TASK_DONE, (data) => handleTaskDone(name, data).catch((e) => logger.error(e)));
    socket.on(EVENTS.TASK_FAILED, (data) => handleTaskFailed(name, data).catch((e) => logger.error(e)));

    socket.on('disconnect', () => {
      workerRegistry.remove(name);
      logger.info('Worker left', { name });
      handleWorkerLeft(name).catch((e) => logger.error(e));
    });
  });
}
