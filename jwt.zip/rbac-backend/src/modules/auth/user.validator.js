import {z} from 'zod';

const pwd  =  z.string()
    .min(8, 'At least 8 Chars in Password')
    .max(25, 'Atmost 25 chars in Password')
    .regex(/[A-Z]/, 'At Least one Capital Letter in Password')
    .regex(/[a-z]/, 'At Least one Small Letter in Password')
    .regex(/[0-9]/, 'At Least one Digit in Password')
    .regex(/[^A-Za-z0-9]/, 'At Least one Special Letter in Password')

export const loginSchema = z.object({
    email : z.email('Invalid Email'),
    password : pwd
    
});

export const registerSchema = z.object({
    email : z.email('Invalid Email'),
    password : pwd,
    name : z.string().min(2, 'Name is very short...'),
    role : z.string().min(3, 'at least 3 chars')
});