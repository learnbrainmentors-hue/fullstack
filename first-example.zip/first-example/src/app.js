import express from 'express';
import { authRoutes } from './modules/auth/routes/auth-routes.js';
export const createApp = ()=>{
    const API_VERSION = "/api/v1";
    console.log('***** Express Type ', typeof express);
    const app = express();
     app.get('/health', (request, response)=>{
        //response.send("Hello Express ");
        response.status(200).json({status : 'OK', uptime : process.uptime()});
    })
  //  app.use(middleware);
    app.use(express.json());
    app.use(`${API_VERSION}/user`, authRoutes);
   
    
    console.log('App is ', typeof app);
    return app;
}
