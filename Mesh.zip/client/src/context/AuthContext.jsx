import { createContext, useContext, useEffect, useState } from 'react';
import { api, tokenStore } from '../lib/api.js';

const AuthContext = createContext(null);

// Keeps the logged-in user in one place, available to every component.
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // On page load: if we saved a token earlier, ask the server who we are
  useEffect(() => {
    if (!tokenStore.get()) return setLoading(false);
    api('/auth/me')
      .then(({ user }) => setUser(user))
      .catch(() => tokenStore.clear()) // token expired or invalid
      .finally(() => setLoading(false));
  }, []);

  async function authenticate(mode, form) {
    const { user, token } = await api(`/auth/${mode}`, { method: 'POST', body: form });
    tokenStore.set(token);
    setUser(user);
  }

  function logout() {
    tokenStore.clear();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, authenticate, logout }}>{children}</AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
