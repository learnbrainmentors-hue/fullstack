// validate(schema) checks req.body with a Zod schema before the controller runs.
// Bad input throws a ZodError, which errorHandler turns into a 400 response.
export const validate = (schema) => (req, res, next) => {
  req.body = schema.parse(req.body); // also removes unknown fields
  next();
};
