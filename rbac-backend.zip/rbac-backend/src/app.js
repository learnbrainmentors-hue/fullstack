import express from 'express';
import { userRoutes } from './modules/auth/auth.route.js';
export function createApp(){
const app = express();
app.use(express.json());
app.use('/api/v1' , userRoutes);
//app.use(middleware); // error middleware
return app;
}
