import { Router } from 'express';
import { interpretPrompt } from './ai.controller.js';
import { validate } from '../../shared/middlewares/validate.js';
import { interpretSchema } from './ai.validation.js';

const router = Router();

router.post('/interpret', validate(interpretSchema), interpretPrompt);

export default router;
