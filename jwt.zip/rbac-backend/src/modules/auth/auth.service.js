import { hashPassword } from "../../shared/utils/hashed.password.js";
import { RoleModel } from "./models/role.js";
import { UserModel } from "./models/user.js";

const loginService = (userInfo)=>{

}

export const registerService = async (userInfo)=>{
    console.log('UserInfo is ::::::  ', userInfo);
    const user = await UserModel.findOne({email : userInfo.email});
    console.log('User ::: DB ', user);
    if(user){
        return false;
    }
    if(userInfo.role ==='admin'){
        return false;
    }
    const userRole = await RoleModel.findOne({name : userInfo.role});
    userInfo.password = hashPassword (userInfo.password);
    userInfo.role = userRole._id;
    await UserModel.create(userInfo);
    return true;
    

}