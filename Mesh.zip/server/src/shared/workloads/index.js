import { z } from 'zod';
import { sipRisk } from './sipRisk.js';
import { primes } from './primes.js';

// Every workload has the same shape: { type, schema, split, run, merge }  (Strategy pattern)
// To add a new one: create a file and add it to this list. Nothing else changes.
const workloads = new Map([sipRisk, primes].map((w) => [w.type, w]));

export function getWorkload(type) {
  const workload = workloads.get(type);
  if (!workload) throw new Error(`Unknown workload: ${type}`);
  return workload;
}

// Public description of every workload (shown in the UI and given to Gemini)
export function listWorkloads() {
  return [...workloads.values()].map((w) => ({
    type: w.type,
    title: w.title,
    description: w.description,
    params: z.toJSONSchema(w.schema, { io: 'input' }),
  }));
}

export const workloadTypes = [...workloads.keys()];

// Are two results the same? Used to catch workers that send fake answers.
// Numbers may differ only by a tiny decimal rounding error.
export function sameResult(a, b) {
  const keys = Object.keys(a);
  if (keys.length !== Object.keys(b).length) return false;
  return keys.every((key) => Math.abs(a[key] - b[key]) <= 1e-9 * Math.max(1, Math.abs(a[key])));
}
