import mongoose from 'mongoose';
import { JOB_STATUS } from '../../shared/constants/status.js';

// A JOB is what the user asked for: "1 million simulations".
const jobSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: { type: String, required: true }, // e.g. 'sip-risk'
    params: { type: Object, required: true },
    prompt: { type: String }, // the English sentence, if the user typed one
    status: { type: String, enum: Object.values(JOB_STATUS), default: JOB_STATUS.QUEUED },
    totalTasks: { type: Number, required: true },
    doneTasks: { type: Number, default: 0 },
    result: { type: Object },
    error: { type: String },
    startedAt: { type: Date },
    finishedAt: { type: Date },
  },
  { timestamps: true, toJSON: { virtuals: true } },
);

// Computed on the fly, never stored: how long the job took
jobSchema.virtual('durationMs').get(function () {
  return this.startedAt && this.finishedAt ? this.finishedAt - this.startedAt : null;
});

export const Job = mongoose.model('Job', jobSchema);
