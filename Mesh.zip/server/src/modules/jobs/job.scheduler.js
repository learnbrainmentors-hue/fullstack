import { Job } from './job.model.js';
import { Task } from './task.model.js';
import { workerRegistry } from '../workers/worker.registry.js';
import { getWorkload, sameResult } from '../../shared/workloads/index.js';
import { JOB_STATUS, TASK_STATUS, MAX_TASK_ATTEMPTS } from '../../shared/constants/status.js';
import { EVENTS } from '../../shared/constants/events.js';
import { emitToUser } from '../../shared/socket/index.js';
import { env } from '../../shared/config/env.js';
import { logger } from '../../shared/utils/logger.js';

// THE BRAIN: hands out tasks, saves results, retries failures, catches cheaters.
// All state lives in MongoDB, so a server restart loses nothing.

// ---------- 1. Give a task to every free worker ----------
export async function assignWork() {
  try {
    for (const worker of workerRegistry.list()) {
      if (worker.busy) continue;
      worker.busy = true; // mark first, so a parallel call can't pick the same worker

      const task = await claimNextTask(worker.name);
      if (!task) {
        worker.busy = false;
        return; // no pending tasks left
      }
      if (!worker.socket.connected) {
        // the worker left while we were claiming: put the task back
        await Task.updateOne({ _id: task._id }, { $set: { status: TASK_STATUS.PENDING, workerName: null } });
        continue;
      }
      worker.socket.emit(EVENTS.TASK_RUN, { taskId: task.id, type: task.type, payload: task.payload });
      await markJobRunning(task.job);
    }
  } catch (err) {
    logger.error(err);
  }
}

// Find a pending task AND mark it running in ONE atomic database step.
// MongoDB updates one document atomically, so two workers can never get the same task.
function claimNextTask(workerName) {
  return Task.findOneAndUpdate(
    { status: TASK_STATUS.PENDING },
    { $set: { status: TASK_STATUS.RUNNING, workerName }, $inc: { attempts: 1 } },
    { sort: { createdAt: 1, index: 1 }, new: true },
  );
}

async function markJobRunning(jobId) {
  // only the first task moves a job from queued -> running
  const job = await Job.findOneAndUpdate(
    { _id: jobId, status: JOB_STATUS.QUEUED },
    { $set: { status: JOB_STATUS.RUNNING, startedAt: new Date() } },
    { new: true },
  );
  if (job) emitToUser(job.owner, EVENTS.JOB_UPDATE, job);
}

// ---------- 2. A worker finished a task ----------
export async function handleTaskDone(workerName, { taskId, result, durationMs }) {
  const worker = workerRegistry.get(workerName);
  const task = await Task.findOne({ _id: taskId, status: TASK_STATUS.RUNNING, workerName });
  if (!task) {
    if (worker) worker.busy = false;
    return assignWork(); // late or duplicate answer: ignore it
  }

  // Spot-check: sometimes re-run the task here and compare (results are deterministic)
  if (Math.random() < env.VERIFY_RATE) {
    const truth = getWorkload(task.type).run(task.payload);
    if (!sameResult(truth, result)) return banCheater(workerName);
  }

  await Task.updateOne({ _id: task._id }, { $set: { status: TASK_STATUS.DONE, result, durationMs } });
  if (worker) {
    worker.busy = false; // free again
    worker.tasksDone += 1;
  }
  workerRegistry.broadcast();

  await updateProgress(task.job, { index: task.index, workerName });
  assignWork(); // this worker is free again: give it the next task
}

async function updateProgress(jobId, finishedTask) {
  // count from the database instead of trusting a +1 counter
  const doneTasks = await Task.countDocuments({ job: jobId, status: TASK_STATUS.DONE });
  const job = await Job.findByIdAndUpdate(jobId, { $set: { doneTasks } }, { new: true });
  if (!job) return;
  emitToUser(job.owner, EVENTS.TASK_UPDATE, { jobId: job.id, ...finishedTask }); // for the task grid
  emitToUser(job.owner, EVENTS.JOB_UPDATE, job);
  if (doneTasks === job.totalTasks) await finishJob(job);
}

// ---------- 3. All tasks done: merge the results ----------
async function finishJob(job) {
  const tasks = await Task.find({ job: job._id, status: TASK_STATUS.DONE }).sort({ index: 1 });
  const result = getWorkload(job.type).merge(tasks.map((t) => t.result), job.params);

  // only ONE caller can move running -> completed, even if two finish at the same instant
  const finished = await Job.findOneAndUpdate(
    { _id: job._id, status: JOB_STATUS.RUNNING },
    { $set: { status: JOB_STATUS.COMPLETED, result, finishedAt: new Date() } },
    { new: true },
  );
  if (finished) {
    logger.info('Job completed', { jobId: job.id, ms: finished.durationMs });
    emitToUser(finished.owner, EVENTS.JOB_UPDATE, finished);
  }
}

// ---------- 4. Failures: retry, or give up after 3 attempts ----------
async function retryOrFail(task, reason) {
  if (task.attempts >= MAX_TASK_ATTEMPTS) {
    await Task.updateOne({ _id: task._id }, { $set: { status: TASK_STATUS.FAILED } });
    const job = await Job.findByIdAndUpdate(
      task.job,
      { $set: { status: JOB_STATUS.FAILED, error: `Task ${task.index} failed: ${reason}`, finishedAt: new Date() } },
      { new: true },
    );
    if (job) emitToUser(job.owner, EVENTS.JOB_UPDATE, job);
    return;
  }
  logger.warn('Retrying task', { taskId: task.id, reason });
  await Task.updateOne({ _id: task._id }, { $set: { status: TASK_STATUS.PENDING, workerName: null } });
}

export async function handleTaskFailed(workerName, { taskId, error }) {
  const worker = workerRegistry.get(workerName);
  if (worker) worker.busy = false;
  const task = await Task.findOne({ _id: taskId, status: TASK_STATUS.RUNNING, workerName });
  if (task) await retryOrFail(task, error);
  assignWork();
}

// A worker disconnected (closed, crashed, Wi-Fi dropped): take back its tasks
export async function handleWorkerLeft(workerName) {
  const tasks = await Task.find({ status: TASK_STATUS.RUNNING, workerName });
  for (const task of tasks) await retryOrFail(task, 'worker disconnected');
  assignWork();
}

// ---------- 5. A worker sent a fake answer ----------
async function banCheater(workerName) {
  logger.warn('Wrong result: banning worker', { workerName });
  workerRegistry.ban(workerName);
  const cheater = workerRegistry.get(workerName);
  if (cheater) cheater.busy = true; // never give it another task

  // throw away everything it did for unfinished jobs; honest workers will redo it
  const runningJobs = await Job.find({ status: JOB_STATUS.RUNNING }).distinct('_id');
  await Task.updateMany(
    { workerName, job: { $in: runningJobs }, status: { $in: [TASK_STATUS.DONE, TASK_STATUS.RUNNING] } },
    { $set: { status: TASK_STATUS.PENDING, workerName: null, result: null } },
  );
  workerRegistry.get(workerName)?.socket.disconnect(true);
  assignWork();
}

// On startup: tasks that were "running" when the server stopped go back to the queue
export async function recoverTasks() {
  const { modifiedCount } = await Task.updateMany(
    { status: TASK_STATUS.RUNNING },
    { $set: { status: TASK_STATUS.PENDING, workerName: null } },
  );
  if (modifiedCount) logger.info(`Recovered ${modifiedCount} unfinished tasks`);
}
