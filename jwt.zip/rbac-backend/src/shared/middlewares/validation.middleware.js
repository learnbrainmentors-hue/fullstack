

export const validateMiddleware  = (schema)=>{
    return (req, res, next)=>{
    const result = schema.safeParse(req.body);
    if(!result.success){
        return res.status(422).json({error:result.error.issues});
    }
    req.body = result.data;
    next(); 
}
}


