import * as authService from './auth.service.js';

// Controllers only speak HTTP: read the request, call the service, send the response.
// No try/catch needed: Express 5 sends errors to errorHandler automatically.

export async function register(req, res) {
  res.status(201).json(await authService.register(req.body));
}

export async function login(req, res) {
  res.json(await authService.login(req.body));
}

export async function me(req, res) {
  res.json({ user: await authService.getMe(req.user.id) });
}
