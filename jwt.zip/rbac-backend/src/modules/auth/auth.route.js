import {Router} from 'express';
import { login, refresh, register } from './auth.controller.js';
import { validateMiddleware } from '../../shared/middlewares/validation.middleware.js';
import { loginSchema, registerSchema } from './user.validator.js';
export const userRoutes = Router();
userRoutes.post('/login', validateMiddleware(loginSchema),login);
userRoutes.post('/register', validateMiddleware(registerSchema), register);
userRoutes.post('/refresh', refresh);
