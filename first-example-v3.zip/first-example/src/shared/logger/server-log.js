import fs from 'node:fs';
export const morganLogStream = ()=>{
    return fs.createWriteStream('/Users/amitsrivastava/Documents/express-learn/first-example/logs/server.log', {flags:'a'});
}