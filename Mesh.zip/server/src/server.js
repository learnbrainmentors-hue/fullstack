import http from 'node:http';
import { env } from './shared/config/env.js';
import { connectDB } from './shared/config/db.js';
import { logger } from './shared/utils/logger.js';
import { initSocket } from './shared/socket/index.js';
import { createApp } from './app.js';
import { registerWorkerSocket } from './modules/workers/worker.socket.js';
import { recoverTasks } from './modules/jobs/job.scheduler.js';

async function start() {
  await connectDB(); // never accept requests before the database is ready
  await recoverTasks(); // put back tasks left "running" by a previous crash

  // One HTTP server shared by Express (REST API) and Socket.IO (live updates)
  const server = http.createServer(createApp());
  const io = initSocket(server); // browsers
  registerWorkerSocket(io); // workers

  server.listen(env.PORT, () => logger.info(`Server running on http://localhost:${env.PORT}`));

  // Graceful shutdown on Ctrl+C or when a host stops the app
  const shutdown = () => {
    logger.info('Shutting down...');
    io.close(() => process.exit(0));
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

start().catch((err) => {
  logger.error(err);
  process.exit(1);
});
