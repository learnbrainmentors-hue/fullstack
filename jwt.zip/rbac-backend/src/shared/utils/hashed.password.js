import bcrypt from 'bcrypt';
const SALT = 10;
export const hashPassword = (plainPwd)=>{
   return  bcrypt.hashSync(plainPwd, SALT)
}

export const comparePassword = (plainPwd, dbHashPwd)=>{
    return bcrypt.compareSync(plainPwd, dbHashPwd);
}