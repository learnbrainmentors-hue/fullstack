import mongoose from 'mongoose';
import { TASK_STATUS } from '../../shared/constants/status.js';

// A TASK is one small piece of a job: "50,000 simulations with seed 47".
const taskSchema = new mongoose.Schema(
  {
    job: { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true },
    type: { type: String, required: true },
    index: { type: Number, required: true }, // task #0, #1, #2 ...
    payload: { type: Object, required: true }, // what split() produced
    status: { type: String, enum: Object.values(TASK_STATUS), default: TASK_STATUS.PENDING },
    workerName: { type: String, default: null }, // who is running it now
    attempts: { type: Number, default: 0 },
    result: { type: Object, default: null },
    durationMs: { type: Number },
  },
  { timestamps: true },
);

// Indexes for the two questions we ask most often (keeps them fast with millions of tasks)
taskSchema.index({ status: 1, createdAt: 1 }); // "give me the oldest pending task"
taskSchema.index({ job: 1, status: 1 }); // "how many tasks of this job are done?"

export const Task = mongoose.model('Task', taskSchema);
