import os from 'node:os';
import dotenv from 'dotenv';
import { io } from 'socket.io-client';
import { getWorkload } from './shared/workloads/index.js';
import { EVENTS } from './shared/constants/events.js';
import { logger } from './shared/utils/logger.js';

// The WORKER: run this on any computer to donate its CPU.  npm run worker
dotenv.config({ quiet: true });

const SERVER_URL = process.env.SERVER_URL || 'http://localhost:5050';
const NAME = process.env.WORKER_NAME || `${os.hostname()}-${process.pid}`;
const CHEAT = process.env.CHEAT === 'true'; // demo only: sends wrong answers

// The worker connects OUT to the server, so it works behind college firewalls.
const socket = io(`${SERVER_URL}/workers`, {
  auth: { token: process.env.WORKER_TOKEN, name: NAME },
});

socket.on('connect', () => logger.info(`Connected to ${SERVER_URL} as "${NAME}"`));

socket.on('disconnect', (reason) => {
  logger.warn(`Disconnected: ${reason}`);
  if (reason === 'io server disconnect') process.exit(0); // the server kicked us out
});

socket.on('connect_error', (err) => {
  if (socket.active) return logger.warn('### Server not reachable, retrying...'+ SERVER_URL); // will retry by itself
  logger.error(`Rejected by server: ${err.message}`); // bad token / banned: retrying won't help
  process.exit(1);
});

// The server sends a task -> run it -> send back the result
socket.on(EVENTS.TASK_RUN, ({ taskId, type, payload }) => {
  const start = Date.now();
  try {
    let result = getWorkload(type).run(payload);
    if (CHEAT) result = { ...result, [Object.keys(result).at(-1)]: 1 }; // a small lie
    const durationMs = Date.now() - start;
    socket.emit(EVENTS.TASK_DONE, { taskId, result, durationMs });
    logger.info(`Done ${type} task in ${durationMs}ms`);
  } catch (err) {
    socket.emit(EVENTS.TASK_FAILED, { taskId, error: err.message });
    logger.error(`Task failed: ${err.message}`);
  }
});
