import express from 'express';
import { userRoutes } from './modules/auth/auth.route.js';
import { authMiddleware } from './shared/middlewares/auth.middleware.js';
import { paymentRoutes } from './modules/payments/payment.route.js';
export function createApp(){
const app = express();
app.use(express.json());
// NOt Protected Routes
app.use('/api/v1' , userRoutes);



// Protected Routes
//app.use('/api/v1', authMiddleware ,orderRoutes);
app.use('/api/v1',authMiddleware, paymentRoutes);

//app.use(middleware); // error middleware
return app;
}
