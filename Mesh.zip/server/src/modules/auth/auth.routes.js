import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import * as controller from './auth.controller.js';
import { validate } from '../../shared/middlewares/validate.js';
import { protect } from '../../shared/middlewares/auth.js';
import { registerSchema, loginSchema } from './auth.validation.js';

const router = Router();

// Max 20 tries per 15 minutes per IP: stops password-guessing bots
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20 });

router.post('/register', authLimiter, validate(registerSchema), controller.register);
router.post('/login', authLimiter, validate(loginSchema), controller.login);
router.get('/me', protect, controller.me);

export default router;
