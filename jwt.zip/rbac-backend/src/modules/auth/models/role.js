import mongoose, {  Schema } from "mongoose";
const roleSchema = new Schema({
    name : {type:String, required: true, unique: true},
    permissions:[{type:Schema.Types.ObjectId, ref : 'permissions'}]
});
export const RoleModel = mongoose.model("roles", roleSchema);