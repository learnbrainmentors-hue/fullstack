import { logger } from '../utils/logger.js';

// Logs every request when it finishes: "POST /api/jobs 201 12ms"
export function requestLogger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    logger.info(`${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - start}ms`);
  });
  next();
}
