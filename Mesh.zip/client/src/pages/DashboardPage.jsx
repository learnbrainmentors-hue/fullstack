import { useAuth } from '../context/AuthContext.jsx';
import { useLiveData } from '../hooks/useLiveData.js';
import AskBox from '../components/AskBox.jsx';
import JobCard from '../components/JobCard.jsx';
import WorkerPanel from '../components/WorkerPanel.jsx';

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const { jobs, workers, cells, connected, saveJob } = useLiveData();

  return (
    <div className="app">
      <header className="topbar">
        <span className="brand brand-small">MeshCompute AI</span>
        <span className={`live ${connected ? 'on' : ''}`}>{connected ? 'Live' : 'Reconnecting…'}</span>
        <span className="spacer" />
        <span className="muted user-name">{user.name}</span>
        <button className="btn btn-quiet" onClick={logout}>Log out</button>
      </header>

      <main className="layout">
        <div className="main-col">
          <AskBox onJobCreated={saveJob} hasWorkers={workers.length > 0} />

          <h2 className="section-title">Your jobs</h2>
          {jobs.length === 0 && <p className="muted">Your jobs will appear here. Ask a question above to start one.</p>}
          {jobs.map((job) => (
            <JobCard key={job._id} job={job} cells={cells[job._id]} />
          ))}
        </div>

        <WorkerPanel workers={workers} />
      </main>
    </div>
  );
}
