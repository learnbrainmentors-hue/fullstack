export const me = (request, response)=>{
    const profileId  = request.params.id; // Path Parameter
    console.log('Profile id ', profileId, ' Type ', typeof profileId);
    const users = [
        {id : 1, name:'Amit'}, 
        {id : 2, name:'Ramesh'}, 
        {id : 3, name:'Rajesh'}];
        const user = users.filter(user=>user.id == profileId)
    response.status(200).json(user);
}

export const register = (request, response)=>{
    const userInfo = request.body;
    console.log('UserInfo ', userInfo);
    if(userInfo.email=='amit@brain-mentors.com'){
        response.status(200).json({message:'Admin Register'});
    }
    else{
    response.status(200).json({message:'Guest Register'});
    }
}