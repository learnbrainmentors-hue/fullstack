import { workerColor } from '../lib/workers.js';

export default function WorkerPanel({ workers }) {
  return (
    <aside className="panel workers" aria-live="polite">
      <h2 className="section-title">Machines on the mesh</h2>
      <p className="workers-count">{workers.length}</p>

      {workers.length === 0 ? (
        <div className="empty">
          <p>No machines connected yet. On any computer, run:</p>
          <code>npm run worker</code>
        </div>
      ) : (
        <ul className="worker-list">
          {workers.map((w) => (
            <li key={w.name} className={w.busy ? 'busy' : ''}>
              <span className="swatch" style={{ background: workerColor(w.name) }} />
              <span className="worker-name">{w.name}</span>
              <span className="muted small">{w.busy ? 'Working' : 'Idle'}, {w.tasksDone} {w.tasksDone === 1 ? 'task' : 'tasks'} done</span>
            </li>
          ))}
        </ul>
      )}
    </aside>
  );
}
