import {Router} from 'express';
import { me, register } from '../controllers/auth-controller.js';
import path from 'path';
export const authRoutes = Router();
// authRoutes.route('/user')
//            .get((request, response)=>{
//             // Logic
//                 response.send("Profile");
//            })
//            .post((request, response)=>{
//             // Logic
//                 response.send("Register")
//            });
authRoutes.get('/:username/:repo', (req, res)=>{
    res.send("User "+req.params.username +" Repo "+req.params.repo);
}) ;
authRoutes.get('/test-response', (req, res)=>{
  
   res.set('token','ABCD2222222222');
   res.json({message:'Token Send'});
    // res.sendStatus(200);
    //res.download(process.env.IMAGE_PATH);
    //res.redirect(301, "queryeg?brand=BrainMentors&price=1111111");
    //res.type('html');
    //res.type("json");
    //res.sendFile('/Users/amitsrivastava/Documents/express-learn/first-example/public/index.html');
    //res.status(200).json({message:"Hello JSON Response"});
   // res.status(200).json({message:"Hello Next JSON Response"});
    // res.type("html");
    //res.send("<h1>Hello HTML Response</h1>");
}) 
authRoutes.get('/queryeg', (req, res)=>{
    console.log("Method Name ", req.method , " Protocol ", req.protocol, " URL ", req.url);
    console.log("Host Name ", req.hostname, " Base URL  ", req.baseUrl);
    const obj = req.query;
    const headerValue = req.headers['authorization'];
    console.log('Header Value ', headerValue);
    console.log('Query ' , obj);
    res.send("Hello Query "+obj.brand+ " "+obj.price);
});
    authRoutes.get('/profile/:id', me);
    authRoutes.post('/register', register);

        //    authRoutes.route("/user")
        //    .get('/profile', me)
        //    .post("/register",register)