import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';

export default function AuthPage() {
  const { authenticate } = useAuth();
  const [mode, setMode] = useState('login'); // 'login' or 'register'
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const isLogin = mode === 'login';
  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await authenticate(mode, form);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth">
      <section className="auth-intro">
        <h1 className="brand">MeshCompute AI</h1>
        <p className="auth-pitch">Turn the idle computers in your lab into one shared supercomputer.</p>
        <p className="muted">Ask a question in plain English. It is split into small tasks, run on every connected computer, and combined into one answer.</p>
      </section>

      <form className="panel auth-form" onSubmit={submit}>
        <h2>{isLogin ? 'Log in' : 'Create your account'}</h2>
        {!isLogin && (
          <label>
            Name
            <input name="name" value={form.name} onChange={update} autoComplete="name" required />
          </label>
        )}
        <label>
          Email
          <input name="email" type="email" value={form.email} onChange={update} autoComplete="email" required />
        </label>
        <label>
          Password
          <input
            name="password"
            type="password"
            value={form.password}
            onChange={update}
            autoComplete={isLogin ? 'current-password' : 'new-password'}
            required
          />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="btn btn-primary" disabled={busy}>
          {isLogin ? 'Log in' : 'Create account'}
        </button>
        <button type="button" className="btn-link" onClick={() => setMode(isLogin ? 'register' : 'login')}>
          {isLogin ? 'New here? Create an account' : 'Already have an account? Log in'}
        </button>
      </form>
    </main>
  );
}
