import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Forward API and socket calls to the Express server (no CORS issues in development)
    proxy: {
      '/api': 'http://localhost:5050',
      '/socket.io': { target: 'ws://localhost:5050', ws: true },
    },
  },
});
