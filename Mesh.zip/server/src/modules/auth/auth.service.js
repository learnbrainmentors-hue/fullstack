import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { User } from './user.model.js';
import { env } from '../../shared/config/env.js';
import { ApiError } from '../../shared/utils/ApiError.js';

const createToken = (user) =>
  jwt.sign({ sub: user.id, name: user.name }, env.JWT_SECRET, { expiresIn: env.JWT_EXPIRES_IN });

// Only these fields ever leave the server (never the password hash)
const publicUser = (user) => ({ id: user.id, name: user.name, email: user.email });

export async function register({ name, email, password }) {
  if (await User.exists({ email })) throw ApiError.conflict('Email is already registered');

  const hashed = await bcrypt.hash(password, 10); // slow on purpose: hard to crack
  const user = await User.create({ name, email, password: hashed });
  return { user: publicUser(user), token: createToken(user) };
}

export async function login({ email, password }) {
  const user = await User.findOne({ email }).select('+password');
  const ok = user && (await bcrypt.compare(password, user.password));
  // Same message for "no such email" and "wrong password": hackers learn nothing
  if (!ok) throw ApiError.unauthorized('Wrong email or password');

  return { user: publicUser(user), token: createToken(user) };
}

export async function getMe(userId) {
  const user = await User.findById(userId);
  if (!user) throw ApiError.notFound('User not found');
  return publicUser(user);
}
