// Backup "AI": understands simple English with no internet and no API key.
// Used when Gemini is not configured or fails.

const UNITS = { k: 1e3, thousand: 1e3, lakh: 1e5, lac: 1e5, million: 1e6, crore: 1e7 };

// "10k" -> "10000", "2 lakh" -> "200000", "1,00,000" -> "100000"
function expandNumbers(text) {
  return text
    .replace(/(\d),(?=\d)/g, '$1')
    .replace(/(\d+(?:\.\d+)?)\s*(k|thousand|lakh|lac|million|crore)\b/g, (_, n, unit) =>
      String(Math.round(Number(n) * UNITS[unit])),
    );
}

export function parseWithRules(prompt) {
  const text = expandNumbers(prompt.toLowerCase());
  const numbers = (text.match(/\d+(\.\d+)?/g) || []).map(Number);

  if (/\b(sip|invest|mutual fund|monthly)/.test(text)) {
    const years = Number(text.match(/(\d+)\s*(years?|yrs?|saal)/)?.[1] ?? 5);
    const simulations = Number(text.match(/(\d+)\s*(simulations?|sims?|runs?)/)?.[1] ?? 1_000_000);
    const monthlyAmount = numbers.find((n) => n >= 100 && n !== simulations) ?? 5000;
    return { type: 'sip-risk', params: { monthlyAmount, years, simulations } };
  }

  if (/prime/.test(text)) {
    const [a, b] = numbers;
    return { type: 'primes', params: b ? { from: a, to: b } : { from: 1, to: a ?? 1_000_000 } };
  }

  return null; // not understood
}
