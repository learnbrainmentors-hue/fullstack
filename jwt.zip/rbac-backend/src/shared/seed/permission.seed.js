import { PermissionModel } from "../../modules/auth/models/permission.js"
export const PERMISSION_SEED = {
    PROFILE_READ : 'profile:read',
    PROFILE_UPDATE : 'profile:update',
    USERS_READ : 'users:read',
    USERS_UPDATE_ROLE : 'users:update:role',
    USERS_DELETE : 'users:delete'

}
export const fillPermissions = async ()=>{
    for(let key in PERMISSION_SEED){
        const name = PERMISSION_SEED[key];
        await PermissionModel.updateOne({name},{ name},{upsert:true});
        console.log('Key is ',key, PERMISSION_SEED[key]);
    }
}
console.log('Permission Seed Done 👍');



