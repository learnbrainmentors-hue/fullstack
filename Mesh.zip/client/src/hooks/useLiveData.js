import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { api, tokenStore } from '../lib/api.js';
import { EVENTS } from '../lib/events.js';

const newestFirst = (a, b) => new Date(b.createdAt) - new Date(a.createdAt);

// Loads jobs once over HTTP, then keeps jobs, task grids and workers live over Socket.IO.
export function useLiveData() {
  const [jobs, setJobs] = useState([]);
  const [workers, setWorkers] = useState([]);
  const [cells, setCells] = useState({}); // { jobId: { taskIndex: workerName } }
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    api('/jobs').then(setJobs).catch(console.error);
    api('/workers').then(setWorkers).catch(console.error);

    const socket = io({ auth: { token: tokenStore.get() } });
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on(EVENTS.WORKERS_UPDATE, setWorkers);
    socket.on(EVENTS.JOB_UPDATE, saveJob);
    socket.on(EVENTS.TASK_UPDATE, ({ jobId, index, workerName }) => {
      setCells((prev) => ({ ...prev, [jobId]: { ...prev[jobId], [index]: workerName } }));
    });

    return () => socket.disconnect(); // clean up when the page closes or the user logs out
  }, []);

  // Update the job if we have it, add it if it's new
  function saveJob(job) {
    setJobs((prev) => [job, ...prev.filter((j) => j._id !== job._id)].sort(newestFirst));
  }

  return { jobs, workers, cells, connected, saveJob };
}
