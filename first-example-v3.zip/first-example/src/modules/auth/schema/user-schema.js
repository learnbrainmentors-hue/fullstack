import {z} from 'zod';
export const userSchema = z.object({
    email : z.email().trim(),
    password: z.string().trim().min(8).max(25),
    name:z.string().trim().min(2).max(25)
})