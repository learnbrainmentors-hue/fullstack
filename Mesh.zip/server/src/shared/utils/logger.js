import winston from 'winston';

const { combine, timestamp, colorize, printf, errors, json } = winston.format;

// Readable, coloured lines for the terminal: "10:42:01 info: Worker joined {"name":"lab-pc-1"}"
const consoleFormat = combine(
  colorize(),
  timestamp({ format: 'HH:mm:ss' }),
  errors({ stack: true }),
  printf(({ level, message, timestamp, stack, ...meta }) => {
    const extra = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : '';
    return `${timestamp} ${level}: ${stack || message}${extra}`;
  }),
);

// Errors are ALSO saved as JSON lines in logs/error.log (searchable later).
export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  transports: [
    new winston.transports.Console({ format: consoleFormat }),
    new winston.transports.File({
      filename: 'logs/error.log',
      level: 'error',
      format: combine(timestamp(), errors({ stack: true }), json()),
    }),
  ],
});
