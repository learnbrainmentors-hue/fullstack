import { useState } from 'react';
import { api } from '../lib/api.js';
import { describeJob, formatNumber } from '../lib/format.js';

const EXAMPLES = [
  'I invest 5000 every month for 3 years. What is my risk? Run 2 million simulations.',
  'SIP of 10k for 10 years',
  'Count primes between 1 and 2 crore',
];

const LABELS = {
  monthlyAmount: 'Monthly amount (₹)',
  years: 'Years',
  expectedReturn: 'Expected return per year',
  volatility: 'Market volatility',
  simulations: 'Simulations',
  seed: 'Random seed',
  from: 'From',
  to: 'To',
};

// Step 1: English -> proposal.  Step 2: the user checks it and clicks Run.
export default function AskBox({ onJobCreated, hasWorkers }) {
  const [prompt, setPrompt] = useState('');
  const [proposal, setProposal] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function run(action) {
    setError('');
    setBusy(true);
    try {
      await action();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const understand = (e) => {
    e.preventDefault();
    run(async () => setProposal(await api('/ai/interpret', { method: 'POST', body: { prompt } })));
  };

  const start = () =>
    run(async () => {
      const job = await api('/jobs', { method: 'POST', body: { ...proposal, prompt } });
      onJobCreated(job);
      setProposal(null);
      setPrompt('');
    });

  return (
    <section className="panel ask">
      <form onSubmit={understand}>
        <label htmlFor="prompt" className="ask-label">What do you want to compute?</label>
        <textarea
          id="prompt"
          rows={3}
          value={prompt}
          onChange={(e) => {
            setPrompt(e.target.value);
            setProposal(null);
          }}
          placeholder="e.g. I invest 5000 every month for 3 years. What is my risk?"
        />
        <div className="ask-row">
          <div className="examples">
            {EXAMPLES.map((text) => (
              <button type="button" key={text} className="chip" onClick={() => { setPrompt(text); setProposal(null); }}>
                {text}
              </button>
            ))}
          </div>
          <button className="btn btn-primary" disabled={busy || prompt.trim().length < 3}>
            Understand
          </button>
        </div>
      </form>

      {proposal && (
        <div className="proposal">
          <div className="proposal-head">
            <strong>{describeJob(proposal)}</strong>
            <span className="badge">Understood by {proposal.source === 'gemini' ? 'Gemini' : 'rules'}</span>
          </div>
          <dl className="params">
            {Object.entries(proposal.params).map(([key, value]) => (
              <div key={key}>
                <dt>{LABELS[key] ?? key}</dt>
                <dd>{typeof value === 'number' ? formatNumber(value) : String(value)}</dd>
              </div>
            ))}
          </dl>
          <div className="proposal-actions">
            <button className="btn btn-primary" onClick={start} disabled={busy}>Run on the mesh</button>
            <button className="btn btn-quiet" onClick={() => setProposal(null)}>Change question</button>
            {!hasWorkers && <span className="muted">No machines connected yet. The job will wait for one.</span>}
          </div>
        </div>
      )}

      {error && <p className="error" role="alert">{error}</p>}
    </section>
  );
}
