import TaskGrid from './TaskGrid.jsx';
import ResultView from './ResultView.jsx';
import { describeJob, formatDuration } from '../lib/format.js';

const STATUS_TEXT = { queued: 'Waiting for a machine', running: 'Running', completed: 'Done', failed: 'Failed' };

export default function JobCard({ job, cells }) {
  return (
    <article className="panel job">
      <header className="job-head">
        <div>
          <h3>{describeJob(job)}</h3>
          {job.prompt && <p className="muted job-prompt">“{job.prompt}”</p>}
        </div>
        <span className={`status status-${job.status}`}>{STATUS_TEXT[job.status]}</span>
      </header>

      <TaskGrid total={job.totalTasks} done={job.doneTasks} cells={cells} />
      <p className="muted small">
        {job.doneTasks} of {job.totalTasks} tasks done
        {job.durationMs != null && ` in ${formatDuration(job.durationMs)}`}
      </p>

      {job.status === 'completed' && <ResultView type={job.type} result={job.result} />}
      {job.error && <p className="error">{job.error}</p>}
    </article>
  );
}
