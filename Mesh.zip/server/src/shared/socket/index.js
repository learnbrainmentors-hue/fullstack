import { Server } from 'socket.io';
import { env } from '../config/env.js';
import { verifyToken } from '../middlewares/auth.js';
import { EVENTS } from '../constants/events.js';

let io = null;

// Creates the Socket.IO server and sets up the browser (dashboard) side.
// Workers use their own namespace, set up in modules/workers.
export function initSocket(httpServer) {
  io = new Server(httpServer, { cors: { origin: env.CLIENT_URL } });

  // Browsers must send their login token to connect
  io.use((socket, next) => {
    try {
      socket.data.user = verifyToken(socket.handshake.auth.token);
      next();
    } catch {
      next(new Error('Unauthorized'));
    }
  });

  // Each user joins a private room, so they only get updates about THEIR jobs
  io.on('connection', (socket) => {
    socket.join(`user:${socket.data.user.id}`);
  });

  return io;
}

export function emitToUser(userId, event, data) {
  io?.to(`user:${userId}`).emit(event, data);
}

export function emitToAll(event, data) {
  io?.emit(event, data);
}

export { EVENTS };
