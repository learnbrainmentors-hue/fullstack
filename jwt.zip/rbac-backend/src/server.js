import http from 'node:http';
import dotenv from 'dotenv';
import { createApp } from './app.js';
import { createDBConnection } from './shared/db/connection.js';
import { fillPermissions } from './shared/seed/permission.seed.js';
import { fillRoles } from './shared/seed/role.seed.js';
import { fillAdmin } from './shared/seed/user.seed.js';
dotenv.config();
const promise = createDBConnection();
promise.then(async ()=>{
    // Setup Code...
    console.log('DB Connected...');
    await fillPermissions();
    await fillRoles();
    try{
    await fillAdmin();
    }
    catch(err){
        console.log('Admin Already There... ');
    }
    // Sever Startup code...
    const server = http.createServer(createApp());
    server.listen(process.env.PORT, (err)=>{
    if(err){
        console.log('Server Crash ', err);
        process.exit(1);
    }
    else{
        console.log('Server Up and Running ', server.address().port);
    }
})
}).catch(err=>{
    console.log('DB Crash ', err);
    process.exit(1);
})

