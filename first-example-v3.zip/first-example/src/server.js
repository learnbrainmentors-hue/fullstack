import http from 'http';
import { createApp } from './app.js';
import { createConnection } from './shared/db/connection.js';
import { logger } from './shared/logger/app-logger.js';
process.on('unhandledRejection', reason=>{
    console.log('UnHandle Rejection ', reason);
    process.exit(1);
})
process.on('uncaughtException', reason=>{
    console.log('Uncaught Exception ', reason);
    process.exit(1);
});
const promise = createConnection();
promise.then(()=>{
    console.log('DB Connection Created....');
    const server = http.createServer(createApp());
    server.listen(process.env.PORT || 1234, (err)=>{
    if(err){
        console.log('Server Crash ', err);
        logger.error("Server Crash "+JSON.stringify(err));
    }

    else{
        logger.debug("Server Up and Running ");
        console.log('Server Up and Running ', server.address().port);
    }
})
}).catch(err=>{
     logger.error("DB Connection Failed "+JSON.stringify(err));
    console.log('DB Connection Failed....', err);
    process.exit(1);
})
