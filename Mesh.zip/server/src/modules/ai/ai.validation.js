import { z } from 'zod';

export const interpretSchema = z.object({
  prompt: z.string().trim().min(3, 'Type a little more').max(500),
});
