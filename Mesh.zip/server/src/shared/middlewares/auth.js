import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { ApiError } from '../utils/ApiError.js';

// Reads a JWT and returns who it belongs to. Also used by the socket server.
export function verifyToken(token) {
  const payload = jwt.verify(token, env.JWT_SECRET);
  return { id: payload.sub, name: payload.name };
}

// Protects a route: needs header "Authorization: Bearer <token>"
export function protect(req, res, next) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme !== 'Bearer' || !token) throw ApiError.unauthorized();

  try {
    req.user = verifyToken(token);
  } catch {
    throw ApiError.unauthorized('Session expired, please log in again');
  }
  next();
}
