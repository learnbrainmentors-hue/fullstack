import { RoleModel } from "../../modules/auth/models/role.js"
import { UserModel } from "../../modules/auth/models/user.js";
import { hashPassword } from "../utils/hashed.password.js";

export const fillAdmin = async ()=>{
    // Search the admin role 
    const adminRole = await RoleModel.findOne({name:'admin'});
    await UserModel.create({
        name:'Admin', 
        email : process.env.ADMIN_EMAIL,
        password: hashPassword (process.env.ADMIN_PWD),
        role : adminRole._id
    });
    console.log("Admin Created...");
}