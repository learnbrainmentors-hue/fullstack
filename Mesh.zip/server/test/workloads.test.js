import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getWorkload, sameResult } from '../src/shared/workloads/index.js';
import { parseWithRules } from '../src/modules/ai/ai.rules.js';

// helper: run a whole job on one computer: validate -> split -> run each -> merge
function runJob(type, params) {
  const workload = getWorkload(type);
  const clean = workload.schema.parse(params);
  return workload.merge(workload.split(clean).map((task) => workload.run(task)), clean);
}

test('same input always gives the same answer (needed to catch cheaters)', () => {
  const params = { monthlyAmount: 5000, years: 3, simulations: 100_000 };
  assert.deepEqual(runJob('sip-risk', params), runJob('sip-risk', params));
});

test('splitting a job does not change the answer', () => {
  // there are exactly 78,498 primes below one million
  assert.equal(runJob('primes', { from: 1, to: 1_000_000 }).primeCount, 78_498);
});

test('bad input is rejected', () => {
  assert.throws(() => getWorkload('sip-risk').schema.parse({ monthlyAmount: 5, years: 3 }));
  assert.throws(() => getWorkload('bitcoin-miner'));
});

test('a tampered result is detected', () => {
  assert.equal(sameResult({ count: 25 }, { count: 25 }), true);
  assert.equal(sameResult({ count: 25 }, { count: 26 }), false);
});

test('rules understand Indian number words', () => {
  assert.deepEqual(parseWithRules('SIP of 10k for 10 years, 2 lakh simulations'), {
    type: 'sip-risk',
    params: { monthlyAmount: 10000, years: 10, simulations: 200000 },
  });
  assert.equal(parseWithRules('tell me a joke'), null);
});
