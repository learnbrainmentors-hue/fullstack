import { formatNumber, formatRupees } from '../lib/format.js';

export default function ResultView({ type, result }) {
  if (type === 'sip-risk') {
    return (
      <div className="result">
        <div className="result-main">
          <span className="result-value">{result.chanceOfLoss}%</span>
          <span>chance of ending with less than you put in</span>
        </div>
        <dl className="result-side">
          <div><dt>You invest</dt><dd>{formatRupees(result.invested)}</dd></div>
          <div><dt>Average final value</dt><dd>{formatRupees(result.averageValue)}</dd></div>
          <div><dt>Futures simulated</dt><dd>{formatNumber(result.simulations)}</dd></div>
        </dl>
      </div>
    );
  }
  if (type === 'primes') {
    return (
      <div className="result">
        <div className="result-main">
          <span className="result-value">{formatNumber(result.primeCount)}</span>
          <span>prime numbers between {formatNumber(result.from)} and {formatNumber(result.to)}</span>
        </div>
      </div>
    );
  }
  return <pre>{JSON.stringify(result, null, 2)}</pre>;
}
