import { Router } from 'express';
import * as controller from './job.controller.js';
import { validate } from '../../shared/middlewares/validate.js';
import { createJobSchema } from './job.validation.js';

const router = Router();

router.post('/', validate(createJobSchema), controller.create);
router.get('/', controller.list);
router.get('/:id', controller.getOne);

export default router;
