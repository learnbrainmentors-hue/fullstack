import { z } from 'zod';
import { workloadTypes } from '../../shared/workloads/index.js';

export const createJobSchema = z.object({
  type: z.enum(workloadTypes),
  params: z.record(z.string(), z.unknown()), // checked in detail by the workload's own schema
  prompt: z.string().max(500).optional(),
});
