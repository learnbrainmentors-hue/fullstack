import { UserModel } from "../models/user-model.js"
// CRUD 
// Create
export const addUser = async (userObject)=>{
   return await  UserModel.create(userObject);
}

// Read
export const getAllUsers = async ()=>{
   return await UserModel.find().select("email name password -_id");
   //.limit(2).skip(2);
}


export const getUser = async ({email, password})=>{
   return await UserModel.findOne({email , password})
}

export const updateUser = async (id, userInfo)=>{
      return await UserModel.findByIdAndUpdate(id, userInfo,{
         returnDocument : "after",
         runValidators :true
      }).select("-password");
}

export const removeUser = async (id)=>{
   return await UserModel.findByIdAndDelete(id);
}