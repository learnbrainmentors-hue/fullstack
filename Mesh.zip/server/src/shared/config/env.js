import dotenv from 'dotenv';
import { z } from 'zod';

// Load server/.env into process.env (quiet: don't print a banner)
dotenv.config({ quiet: true });

// Every setting the server needs, with its rule and default.
const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().default(5000),
  MONGO_URI: z.string().min(1, 'MONGO_URI is required'),
  JWT_SECRET: z.string().min(16, 'JWT_SECRET must be at least 16 characters'),
  JWT_EXPIRES_IN: z.string().default('7d'),
  CLIENT_URL: z.string().default('http://localhost:5173'),
  WORKER_TOKEN: z.string().min(6, 'WORKER_TOKEN must be at least 6 characters'),
  VERIFY_RATE: z.coerce.number().min(0).max(1).default(0.2),
  GEMINI_API_KEY: z.string().optional(),
  GEMINI_MODEL: z.string().default('gemini-2.5-flash'),
});

const result = envSchema.safeParse(process.env);

// Fail fast: a wrong setting stops the server at startup, not at 2 a.m. in production.
if (!result.success) {
  console.error('Invalid .env settings:');
  for (const issue of result.error.issues) console.error(`  - ${issue.path.join('.')}: ${issue.message}`);
  process.exit(1);
}

export const env = Object.freeze(result.data);
