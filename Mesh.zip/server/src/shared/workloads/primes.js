import { z } from 'zod';

const NUMBERS_PER_TASK = 500_000;

function isPrime(n) {
  if (n < 2) return false;
  if (n % 2 === 0) return n === 2;
  for (let d = 3; d * d <= n; d += 2) if (n % d === 0) return false; // only up to √n, odd only
  return true;
}

// Count prime numbers in a range (the maths behind RSA encryption keys).
export const primes = {
  type: 'primes',
  title: 'Prime Counter',
  description: 'Count the prime numbers between two numbers.',

  schema: z
    .object({
      from: z.number().int().min(1),
      to: z.number().int().max(100_000_000),
    })
    .refine((p) => p.to > p.from, { message: '"to" must be bigger than "from"' }),

  split({ from, to }) {
    const tasks = [];
    for (let start = from; start <= to; start += NUMBERS_PER_TASK) {
      tasks.push({ from: start, to: Math.min(start + NUMBERS_PER_TASK - 1, to) });
    }
    return tasks;
  },

  run({ from, to }) {
    let count = 0;
    for (let n = from; n <= to; n++) if (isPrime(n)) count++;
    return { count };
  },

  merge(results, params) {
    return { ...params, primeCount: results.reduce((a, r) => a + r.count, 0) };
  },
};
