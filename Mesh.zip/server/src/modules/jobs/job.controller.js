import * as jobService from './job.service.js';

export async function create(req, res) {
  res.status(201).json(await jobService.createJob(req.user.id, req.body));
}

export async function list(req, res) {
  res.json(await jobService.listJobs(req.user.id));
}

export async function getOne(req, res) {
  res.json(await jobService.getJob(req.user.id, req.params.id));
}
