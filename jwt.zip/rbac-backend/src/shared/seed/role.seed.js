import { PermissionModel } from "../../modules/auth/models/permission.js";
import { RoleModel } from "../../modules/auth/models/role.js";
import { PERMISSION_SEED } from "./permission.seed.js";

const P  = PERMISSION_SEED;

export const ROLE_SEED = {
    user : [P.PROFILE_READ, P.PROFILE_UPDATE],
    admin:Object.values(P),
    guest : [P.PROFILE_READ]
}

export const fillRoles = async ()=>{

    for(let roleName in ROLE_SEED){
        const permsWithIds = await PermissionModel.find({name : {$in : ROLE_SEED[roleName]}});
        await RoleModel.updateOne({name: roleName},
            {name:roleName, permissions : permsWithIds.map(e=>e._id)  }, {upsert:true})
    }
    console.log('Role Updated.. ');
}