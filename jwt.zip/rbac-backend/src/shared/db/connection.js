import mongoose from 'mongoose';
export const createDBConnection = async ()=>{
    return await mongoose.connect(process.env.DB_URL, {maxPoolSize:50})
}