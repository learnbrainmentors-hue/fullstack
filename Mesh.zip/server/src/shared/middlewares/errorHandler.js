import { ZodError } from 'zod';
import { ApiError } from '../utils/ApiError.js';
import { logger } from '../utils/logger.js';

export function notFound(req, res) {
  res.status(404).json({ message: `Route ${req.method} ${req.originalUrl} not found` });
}

// ONE place that turns every error into the same JSON shape: { message, errors? }
// Express knows this is the error handler because it has 4 parameters.
export function errorHandler(err, req, res, _next) {
  if (err instanceof ZodError) {
    const errors = err.issues.map((i) => ({ field: i.path.join('.'), message: i.message }));
    return res.status(400).json({ message: errors[0].message, errors });
  }
  if (err instanceof ApiError) return res.status(err.statusCode).json({ message: err.message });
  if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid id' });
  if (err.code === 11000) return res.status(409).json({ message: 'Already exists' });

  // Anything else is a bug: log everything, show the user nothing sensitive.
  logger.error(err);
  res.status(500).json({ message: 'Something went wrong' });
}
