import { addUser, getAllUsers, getUser, removeUser, updateUser } from "../services/user-service.js";

export const me = (request, response)=>{
    const profileId  = request.params.id; // Path Parameter
    console.log('Profile id ', profileId, ' Type ', typeof profileId);
    const users = [
        {id : 1, name:'Amit'}, 
        {id : 2, name:'Ramesh'}, 
        {id : 3, name:'Rajesh'}];
        const user = users.filter(user=>user.id == profileId)
    response.status(200).json(user);
}




export const listUsers= async(req, res)=>{
    const users  = await getAllUsers();
    res.status(200).json(users);
}


export const login =async (req, res)=>{
    const userInfo = req.body;
    const user = await getUser(userInfo);
    if(!user){
        res.status(404).json({message:'User Not Found'});
    }
    else{
        res.status(200).json({message : 'User Found', user});
    }
}

export const updateUserInfo = async (req, res)=>{
    const id = req.params.id;
    const userInfo = req.body;
    const user = await updateUser(id, userInfo);
    if(!user){
        res.status(404).json({message : "User Not Found Not Updated"});
    }
    else{
        res.status(200).json({message:"User Record Updated... ", user});
    }
}

export const removeUserInfo = async (req, res)=>{
    const id = req.params.id;
    const user = await removeUser(id);
    console.log("id "+id +" Remove User "+user);
    if(!user){
        res.status(404).json({message : "User Not Found Not Deleted"});
    }
    else{
        res.status(200).json({message:"User Record Deleted... ", user});
    }
}



export const register = async (request, response)=>{
    const userInfo = request.body;
    console.log('UserInfo ', userInfo);
    try{
    const doc = await addUser(userInfo);
    console.log('Doc is ', doc);
    response.status(201).json({message:'User Register',  doc : doc});
    }
    catch(err){
        console.log('Error is ', err);
        response.status(500).json({message:'Something went wrong'});
    }
    // if(userInfo.email=='amit@brain-mentors.com'){
    //     response.status(200).json({message:'Admin Register'});
    // }
    // else{
    // response.status(200).json({message:'Guest Register'});
    // }
}