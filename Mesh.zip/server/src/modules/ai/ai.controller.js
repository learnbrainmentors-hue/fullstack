import { interpret } from './ai.service.js';

export async function interpretPrompt(req, res) {
  res.json(await interpret(req.body.prompt));
}
