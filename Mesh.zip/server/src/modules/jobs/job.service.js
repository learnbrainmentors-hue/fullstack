import { Job } from './job.model.js';
import { Task } from './task.model.js';
import { getWorkload } from '../../shared/workloads/index.js';
import { ApiError } from '../../shared/utils/ApiError.js';
import { assignWork } from './job.scheduler.js';

export async function createJob(ownerId, { type, params, prompt }) {
  const workload = getWorkload(type);
  const cleanParams = workload.schema.parse(params); // checks values + fills defaults
  const pieces = workload.split(cleanParams); // one job -> many small tasks

  const job = await Job.create({ owner: ownerId, type, params: cleanParams, prompt, totalTasks: pieces.length });
  await Task.insertMany(pieces.map((payload, index) => ({ job: job._id, type, index, payload })));

  assignWork(); // hand the new tasks to free workers (we don't wait for it)
  return job;
}

export function listJobs(ownerId) {
  return Job.find({ owner: ownerId }).sort({ createdAt: -1 }).limit(20);
}

export async function getJob(ownerId, jobId) {
  // filtering by owner too: nobody can read someone else's job
  const job = await Job.findOne({ _id: jobId, owner: ownerId });
  if (!job) throw ApiError.notFound('Job not found');
  return job;
}
